import Image from "next/image";

export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-50 to-teal-50 dark:from-zinc-950 dark:to-black font-sans">
      {/* Navigation */}
      <nav className="border-b bg-white/80 dark:bg-zinc-900/80 backdrop-blur-md sticky top-0 z-50">
        <div className="max-w-6xl mx-auto px-6 py-4 flex justify-between items-center">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-emerald-600 rounded-xl flex items-center justify-center text-white font-bold text-xl">🧬</div>
            <div>
              <h1 className="font-semibold text-2xl tracking-tight text-emerald-950 dark:text-white">BioMaster Academy</h1>
              <p className="text-xs text-emerald-600 dark:text-emerald-400 -mt-1">Learn Biology • Excel in Exams</p>
            </div>
          </div>
          <div className="flex gap-6 text-sm">
            <a href="#curriculum" className="hover:text-emerald-600 transition-colors">Curriculum</a>
            <a href="#quiz" className="hover:text-emerald-600 transition-colors">Quizzes</a>
            <a href="#book" className="hover:text-emerald-600 transition-colors">Book a Class</a>
            <a href="#about" className="hover:text-emerald-600 transition-colors">About Author</a>
          </div>
        </div>
      </nav>

      {/* Hero */}
      <section className="pt-24 pb-16 px-6 text-center">
        <div className="max-w-4xl mx-auto">
          <div className="inline-flex items-center gap-2 bg-white dark:bg-zinc-800 rounded-full px-4 py-1 text-sm mb-6 border">
            <span className="text-emerald-600">✦</span> Senior Secondary & Undergraduate Biology
          </div>
          <h2 className="text-6xl font-semibold tracking-tighter text-balance mb-6 text-emerald-950 dark:text-white">
            Master Biology with Expert Guidance
          </h2>
          <p className="text-xl text-zinc-600 dark:text-zinc-400 max-w-2xl mx-auto">
            Interactive lessons, quizzes, and personalized support from a seasoned educator.
          </p>
          <div className="mt-10 flex gap-4 justify-center">
            <a href="#quiz" className="bg-emerald-600 hover:bg-emerald-700 text-white px-8 py-4 rounded-2xl font-medium text-lg transition-all active:scale-[0.985]">
              Start Learning Now
            </a>
            <a href="#book" className="border border-emerald-600 text-emerald-700 dark:text-emerald-400 px-8 py-4 rounded-2xl font-medium text-lg hover:bg-emerald-50 dark:hover:bg-zinc-900 transition-all">
              Book One-to-One Class
            </a>
          </div>
        </div>
      </section>

      {/* Author Section */}
      <section id="about" className="bg-white dark:bg-zinc-900 py-20 border-t border-b">
        <div className="max-w-4xl mx-auto px-6">
          <h3 className="text-4xl font-semibold text-center mb-12 text-emerald-950 dark:text-white">Meet the Author</h3>
          
          <div className="flex flex-col md:flex-row gap-12 items-center">
            <div className="w-64 h-64 bg-gradient-to-br from-emerald-600 to-teal-600 rounded-3xl flex-shrink-0 flex items-center justify-center text-8xl">
              👨‍🏫
            </div>
            
            <div className="space-y-6">
              <div>
                <h4 className="text-3xl font-semibold text-emerald-950 dark:text-white">Rev. Olukunle Ope</h4>
                <p className="text-emerald-600 dark:text-emerald-400 text-xl">25+ Years Experience in Biology & ICT</p>
              </div>
              
              <p className="text-lg leading-relaxed text-zinc-600 dark:text-zinc-400">
                I am passionate about coaching young people and all those who seek legitimate means to success. 
                With over 25 years of teaching experience, I have helped thousands of students excel in Biology.
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-4">
                <div className="flex items-center gap-3">
                  <div className="text-emerald-600">✉️</div>
                  <div>
                    <p className="font-medium">Email</p>
                    <a href="mailto:olukunle40@yahoo.com" className="text-emerald-600 hover:underline">olukunle40@yahoo.com</a><br />
                    <a href="mailto:olukunle7@gmail.com" className="text-emerald-600 hover:underline">olukunle7@gmail.com</a>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <div className="text-emerald-600">📞</div>
                  <div>
                    <p className="font-medium">Phone</p>
                    <a href="tel:+2348164288633" className="text-emerald-600 hover:underline">+234 816 428 8633</a>
                  </div>
                </div>
              </div>

              <a href="https://bookslibrrary.blogspot.com" target="_blank" className="inline-flex items-center gap-2 text-emerald-600 hover:text-emerald-700 font-medium">
                Visit my Blog → bookslibrrary.blogspot.com
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* Placeholder sections for expansion */}
      <section id="curriculum" className="py-20 px-6 bg-zinc-50 dark:bg-zinc-950">
        <div className="max-w-6xl mx-auto text-center">
          <h3 className="text-4xl font-semibold mb-4">Curriculum Modules</h3>
          <p className="text-zinc-600 dark:text-zinc-400 mb-12">Coming soon: Full senior secondary & undergraduate syllabus with hundreds of questions</p>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-left max-w-3xl mx-auto">
            {["Cell Biology", "Genetics", "Ecology", "Human Physiology"].map((t, i) => (
              <div key={i} className="bg-white dark:bg-zinc-900 p-6 rounded-2xl border">📖 {t}</div>
            ))}
          </div>
        </div>
      </section>

      <footer className="bg-emerald-950 text-white py-12 text-center">
        <p>© {new Date().getFullYear()} BioMaster Academy • Developed with passion by Rev. Olukunle Ope</p>
        <p className="text-sm text-emerald-400 mt-2">All rights reserved</p>
      </footer>
    </div>
  );
}
